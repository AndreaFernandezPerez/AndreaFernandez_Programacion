import controller.EjercicioDos;
import controller.EjercicioUno;

public class Main {
    public static void main(String[] args) {

        EjercicioUno ejercicioUno = new EjercicioUno();
        //ejercicioUno.lecturaFichero();

        EjercicioDos ejercicioDos = new EjercicioDos();
        //ejercicioDos.lectura();


    }// fin de main
}// fin de clase Main
