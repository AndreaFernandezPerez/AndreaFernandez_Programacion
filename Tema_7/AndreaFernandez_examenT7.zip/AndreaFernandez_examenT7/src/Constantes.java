public interface Constantes {

    double IVA_COMIDAS = 0.10;
    double IVA_BEBIDAS = 0.21;
    String CIF = "A12345678";
}
